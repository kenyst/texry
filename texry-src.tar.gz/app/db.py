from __future__ import annotations

import asyncio
from collections import defaultdict
from contextlib import asynccontextmanager
from datetime import UTC, datetime
from pathlib import Path
from typing import AsyncIterator

from sqlalchemy import event
from sqlalchemy.ext.asyncio import AsyncEngine, AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.orm import DeclarativeBase


class Base(DeclarativeBase):
    pass


def utcnow() -> datetime:
    """Все даты в БД хранятся как naive UTC."""
    return datetime.now(UTC).replace(tzinfo=None)


_engine: AsyncEngine | None = None
_sessionmaker: async_sessionmaker[AsyncSession] | None = None


def normalize_db_url(url: str) -> tuple[str, dict]:
    """Принимает строку подключения как её выдают Neon/Supabase/Render (postgres://…?sslmode=require)
    и возвращает URL для SQLAlchemy + доп. параметры движка."""
    url = url.strip()
    kwargs: dict = {}
    for prefix in ("postgres://", "postgresql://", "postgresql+asyncpg://"):
        if url.startswith(prefix):
            url = "postgresql+psycopg://" + url[len(prefix):]
            break
    if url.startswith("postgresql+psycopg://"):
        kwargs["pool_pre_ping"] = True  # бесплатные БД засыпают и рвут соединения
        kwargs["pool_recycle"] = 240
        host = url.split("@", 1)[-1].split("/", 1)[0]
        if "pooler" in host or ":6543" in host:
            kwargs["connect_args"] = {"prepare_threshold": None}  # PgBouncer в режиме транзакций
    return url, kwargs


def init_engine(url: str) -> AsyncEngine:
    global _engine, _sessionmaker
    url, kwargs = normalize_db_url(url)
    if url.startswith("sqlite"):
        path = url.split(":///", 1)[-1]
        if path and path != ":memory:":
            Path(path).parent.mkdir(parents=True, exist_ok=True)
        kwargs["connect_args"] = {"timeout": 30}
    _engine = create_async_engine(url, **kwargs)
    if url.startswith("sqlite"):

        @event.listens_for(_engine.sync_engine, "connect")
        def _sqlite_pragmas(dbapi_conn, _):  # pragma: no cover - инфраструктура
            cur = dbapi_conn.cursor()
            cur.execute("PRAGMA journal_mode=WAL")
            cur.execute("PRAGMA foreign_keys=ON")
            cur.close()

    _sessionmaker = async_sessionmaker(_engine, expire_on_commit=False)
    return _engine


async def create_all() -> None:
    from app import models  # noqa: F401  регистрирует таблицы

    assert _engine is not None
    async with _engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)


async def dispose() -> None:
    if _engine is not None:
        await _engine.dispose()


@asynccontextmanager
async def session_scope() -> AsyncIterator[AsyncSession]:
    assert _sessionmaker is not None, "init_engine() не вызван"
    async with _sessionmaker() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise


async def get_session() -> AsyncIterator[AsyncSession]:
    async with session_scope() as s:
        yield s


# Пер-пользовательские блокировки: защищают от гонок при параллельных запросах
# (тапы, ходы, платежи). Для нескольких инстансов дополнительно используется
# SELECT ... FOR UPDATE в PostgreSQL.
_user_locks: defaultdict[int, asyncio.Lock] = defaultdict(asyncio.Lock)


def user_lock(user_id: int) -> asyncio.Lock:
    return _user_locks[user_id]
