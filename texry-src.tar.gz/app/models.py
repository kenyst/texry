from __future__ import annotations

from datetime import datetime

from sqlalchemy import BigInteger, Boolean, DateTime, Float, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.db import Base, utcnow


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=False)  # Telegram user id
    username: Mapped[str | None] = mapped_column(String(64))
    first_name: Mapped[str] = mapped_column(String(128), default="")
    last_name: Mapped[str | None] = mapped_column(String(128))
    photo_url: Mapped[str | None] = mapped_column(String(512))
    language: Mapped[str | None] = mapped_column(String(8))
    is_premium: Mapped[bool] = mapped_column(Boolean, default=False)
    has_photo: Mapped[bool | None] = mapped_column(Boolean)
    started_bot: Mapped[bool] = mapped_column(Boolean, default=False)

    ref_code: Mapped[str] = mapped_column(String(16), unique=True, index=True)
    referred_by_id: Mapped[int | None] = mapped_column(BigInteger, ForeignKey("users.id"), index=True)

    # Телефон хранится только в виде HMAC-хеша + последние цифры для админки
    phone_hash: Mapped[str | None] = mapped_column(String(64), unique=True)
    phone_tail: Mapped[str | None] = mapped_column(String(8))
    phone_verified_at: Mapped[datetime | None] = mapped_column(DateTime)

    risk_score: Mapped[int] = mapped_column(Integer, default=0)
    risk_flags: Mapped[str] = mapped_column(String(256), default="")
    is_banned: Mapped[bool] = mapped_column(Boolean, default=False)

    pending_bonus_mb: Mapped[int] = mapped_column(BigInteger, default=0)  # бонусы, ждущие активной подписки

    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    last_seen_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)

    @property
    def phone_verified(self) -> bool:
        return self.phone_verified_at is not None

    def add_flag(self, flag: str, score: int) -> None:
        flags = set(filter(None, self.risk_flags.split(",")))
        if flag in flags:
            return
        flags.add(flag)
        self.risk_flags = ",".join(sorted(flags))
        self.risk_score = (self.risk_score or 0) + score


class Subscription(Base):
    __tablename__ = "subscriptions"

    user_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("users.id"), primary_key=True)
    plan_id: Mapped[str] = mapped_column(String(16))
    devices: Mapped[int] = mapped_column(Integer, default=1)
    started_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    expires_at: Mapped[datetime] = mapped_column(DateTime)
    traffic_limit_mb: Mapped[int] = mapped_column(BigInteger, default=0)
    traffic_used_mb: Mapped[int] = mapped_column(BigInteger, default=0)
    energy_x2: Mapped[bool] = mapped_column(Boolean, default=False)
    # Заполнятся, когда подключим VPN
    vpn_key: Mapped[str | None] = mapped_column(Text)
    sub_url: Mapped[str | None] = mapped_column(String(512))
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, onupdate=utcnow)

    def is_active(self, now: datetime | None = None) -> bool:
        return self.expires_at > (now or utcnow())


class Payment(Base):
    __tablename__ = "payments"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("users.id"), index=True)
    code: Mapped[str] = mapped_column(String(16), unique=True, index=True)
    kind: Mapped[str] = mapped_column(String(16))  # subscription | devices | x2
    plan_id: Mapped[str | None] = mapped_column(String(16))
    months: Mapped[int] = mapped_column(Integer, default=0)
    devices: Mapped[int] = mapped_column(Integer, default=1)
    amount: Mapped[int] = mapped_column(Integer)  # ₽
    status: Mapped[str] = mapped_column(String(16), default="pending", index=True)
    # pending | paid | underpaid | expired | cancelled
    donation_id: Mapped[int | None] = mapped_column(BigInteger, unique=True)
    paid_amount: Mapped[float | None] = mapped_column(Float)
    note: Mapped[str | None] = mapped_column(String(256))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    expires_at: Mapped[datetime] = mapped_column(DateTime)
    paid_at: Mapped[datetime | None] = mapped_column(DateTime)


class Donation(Base):
    """Каждый обработанный донат DonationAlerts — чтобы один донат нельзя было засчитать дважды."""

    __tablename__ = "donations"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=False)
    amount: Mapped[float] = mapped_column(Float)
    currency: Mapped[str] = mapped_column(String(8))
    username: Mapped[str | None] = mapped_column(String(128))
    message: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[str | None] = mapped_column(String(32))
    payment_id: Mapped[int | None] = mapped_column(Integer, ForeignKey("payments.id"))
    result: Mapped[str] = mapped_column(String(24), default="no_code")
    processed_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class Referral(Base):
    __tablename__ = "referrals"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    referrer_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("users.id"), index=True)
    invitee_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("users.id"), unique=True)
    status: Mapped[str] = mapped_column(String(16), default="joined", index=True)
    # joined — пришёл по ссылке; credited — бонус начислен; hold — на ручной проверке; rejected
    bonus_mb: Mapped[int] = mapped_column(BigInteger, default=0)
    reason: Mapped[str | None] = mapped_column(String(128))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    credited_at: Mapped[datetime | None] = mapped_column(DateTime)


class PromoCode(Base):
    """Промокоды привязаны к аккаунту-владельцу и применяются только к нему."""

    __tablename__ = "promo_codes"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    code: Mapped[str] = mapped_column(String(24), unique=True)
    user_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("users.id"), index=True)
    source: Mapped[str] = mapped_column(String(16))  # tapper | game | admin
    kind: Mapped[str] = mapped_column(String(16))  # mb | months
    value: Mapped[int] = mapped_column(Integer)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    applied_at: Mapped[datetime | None] = mapped_column(DateTime)


class TapState(Base):
    __tablename__ = "tap_states"

    user_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("users.id"), primary_key=True)
    day: Mapped[str] = mapped_column(String(10), default="")
    energy_used: Mapped[int] = mapped_column(Integer, default=0)
    score: Mapped[int] = mapped_column(Integer, default=0)
    total_taps: Mapped[int] = mapped_column(BigInteger, default=0)
    x2_left: Mapped[int] = mapped_column(Integer, default=0)
    promos: Mapped[int] = mapped_column(Integer, default=0)
    tokens: Mapped[float] = mapped_column(Float, default=0.0)
    last_batch_at: Mapped[float] = mapped_column(Float, default=0.0)
    suspicious_batches: Mapped[int] = mapped_column(Integer, default=0)


class GameSession(Base):
    __tablename__ = "game_sessions"

    user_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("users.id"), primary_key=True)
    seed: Mapped[str] = mapped_column(String(64))
    state: Mapped[str] = mapped_column(Text)  # JSON: board, tray, used, score, over, moves
    best_score: Mapped[int] = mapped_column(BigInteger, default=0)
    rewarded: Mapped[bool] = mapped_column(Boolean, default=False)
    last_move_at: Mapped[float] = mapped_column(Float, default=0.0)
    started_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class GameReward(Base):
    __tablename__ = "game_rewards"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("users.id"), index=True)
    score: Mapped[int] = mapped_column(BigInteger)
    moves: Mapped[int] = mapped_column(Integer)
    promo_id: Mapped[int | None] = mapped_column(Integer, ForeignKey("promo_codes.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class KV(Base):
    """Служебные значения: токены DonationAlerts и т.п."""

    __tablename__ = "kv"

    key: Mapped[str] = mapped_column(String(64), primary_key=True)
    value: Mapped[str] = mapped_column(Text)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, onupdate=utcnow)


__all__ = [
    "User",
    "Subscription",
    "Payment",
    "Donation",
    "Referral",
    "PromoCode",
    "TapState",
    "GameSession",
    "GameReward",
    "KV",
]
