"""Клиент DonationAlerts API + фоновый поллер донатов.

Документация: https://www.donationalerts.com/apidoc
- OAuth: https://www.donationalerts.com/oauth/authorize и /oauth/token (authorization_code, refresh_token)
- Донаты: GET /api/v1/alerts/donations (scope oauth-donation-index), новые — первыми, пагинация ?page=
- Лимит: 60 запросов в минуту
"""
from __future__ import annotations

import asyncio
import hashlib
import hmac
import json
import logging
import time
from urllib.parse import urlencode

import httpx
from sqlalchemy import select

from app.config import Settings
from app.db import session_scope
from app.models import KV, Donation
from app.services import payments as payment_service

log = logging.getLogger(__name__)

DA_BASE = "https://www.donationalerts.com"
SCOPES = "oauth-user-show oauth-donation-index"
KV_TOKEN = "da_token"
MAX_PAGES = 5


# ---------- OAuth ----------

def sign_state(admin_id: int, secret: str, now: int | None = None) -> str:
    ts = int(now if now is not None else time.time())
    payload = f"{admin_id}.{ts}"
    sig = hmac.new(secret.encode(), f"da:{payload}".encode(), hashlib.sha256).hexdigest()[:32]
    return f"{payload}.{sig}"


def verify_state(state: str, secret: str, max_age: int = 900) -> int | None:
    try:
        admin_id, ts, sig = state.split(".")
        expected = hmac.new(secret.encode(), f"da:{admin_id}.{ts}".encode(), hashlib.sha256).hexdigest()[:32]
        if not hmac.compare_digest(expected, sig) or time.time() - int(ts) > max_age:
            return None
        return int(admin_id)
    except ValueError:
        return None


def redirect_uri(settings: Settings) -> str:
    return settings.base_url.rstrip("/") + "/da/callback"


def authorize_url(settings: Settings, state: str) -> str:
    q = urlencode({
        "client_id": settings.da_client_id,
        "redirect_uri": redirect_uri(settings),
        "response_type": "code",
        "scope": SCOPES,
        "state": state,
    })
    return f"{DA_BASE}/oauth/authorize?{q}"


async def _save_token(data: dict) -> None:
    token = {
        "access_token": data["access_token"],
        "refresh_token": data.get("refresh_token"),
        "expires_at": time.time() + int(data.get("expires_in", 3600)),
    }
    async with session_scope() as s:
        row = await s.get(KV, KV_TOKEN)
        if row:
            row.value = json.dumps(token)
        else:
            s.add(KV(key=KV_TOKEN, value=json.dumps(token)))


async def _load_token() -> dict | None:
    async with session_scope() as s:
        row = await s.get(KV, KV_TOKEN)
        return json.loads(row.value) if row else None


async def exchange_code(settings: Settings, code: str, client: httpx.AsyncClient | None = None) -> None:
    async with _client(client) as c:
        r = await c.post(f"{DA_BASE}/oauth/token", data={
            "grant_type": "authorization_code",
            "client_id": settings.da_client_id,
            "client_secret": settings.da_client_secret,
            "redirect_uri": redirect_uri(settings),
            "code": code,
        })
        r.raise_for_status()
        await _save_token(r.json())


async def _refresh(settings: Settings, refresh_token: str, c: httpx.AsyncClient) -> dict:
    r = await c.post(f"{DA_BASE}/oauth/token", data={
        "grant_type": "refresh_token",
        "refresh_token": refresh_token,
        "client_id": settings.da_client_id,
        "client_secret": settings.da_client_secret,
        "scope": SCOPES,
    })
    r.raise_for_status()
    data = r.json()
    await _save_token(data)
    return await _load_token() or {}


class _client:
    def __init__(self, c: httpx.AsyncClient | None):
        self._c = c
        self._own = c is None

    async def __aenter__(self) -> httpx.AsyncClient:
        if self._c is None:
            self._c = httpx.AsyncClient(timeout=20)
        return self._c

    async def __aexit__(self, *exc):
        if self._own and self._c is not None:
            await self._c.aclose()


async def access_token(settings: Settings, c: httpx.AsyncClient) -> str | None:
    if settings.da_access_token:
        return settings.da_access_token
    tok = await _load_token()
    if not tok:
        return None
    if tok.get("expires_at", 0) - time.time() < 300 and tok.get("refresh_token"):
        tok = await _refresh(settings, tok["refresh_token"], c)
    return tok.get("access_token")


async def token_status(settings: Settings) -> str:
    if settings.da_access_token:
        return "токен задан в .env"
    tok = await _load_token()
    if not tok:
        return "не авторизовано"
    left = int((tok.get("expires_at", 0) - time.time()) / 3600)
    return f"авторизовано, токен обновится автоматически (истекает через ~{left} ч)"


# ---------- Поллер ----------

async def fetch_new_donations(settings: Settings, c: httpx.AsyncClient) -> list[dict]:
    token = await access_token(settings, c)
    if not token:
        return []
    headers = {"Authorization": f"Bearer {token}"}
    collected: list[dict] = []
    for page in range(1, MAX_PAGES + 1):
        r = await c.get(f"{DA_BASE}/api/v1/alerts/donations", params={"page": page}, headers=headers)
        if r.status_code == 401 and not settings.da_access_token:
            tok = await _load_token()
            if tok and tok.get("refresh_token"):
                await _refresh(settings, tok["refresh_token"], c)
            return []
        r.raise_for_status()
        items = r.json().get("data", [])
        if not items:
            break
        ids = [int(d["id"]) for d in items]
        async with session_scope() as s:
            known = set((await s.scalars(select(Donation.id).where(Donation.id.in_(ids)))).all())
        collected.extend(d for d in items if int(d["id"]) not in known)
        if known:  # дошли до уже обработанных
            break
    collected.sort(key=lambda d: int(d["id"]))
    return collected


async def poll_once(settings: Settings, c: httpx.AsyncClient, expire: bool = True) -> int:
    donations = await fetch_new_donations(settings, c)
    processed = 0
    for raw in donations:
        try:
            d = payment_service.DonationIn.from_api(raw)
        except (KeyError, ValueError, TypeError):
            log.warning("skip malformed donation: %s", raw)
            continue
        async with session_scope() as s:
            result = await payment_service.process_donation(s, d, settings)
        log.info("donation %s → %s", d.id, result)
        processed += 1
    if expire:
        async with session_scope() as s:
            await payment_service.expire_stale(s)
    return processed


async def run_poller(settings: Settings, stop: asyncio.Event) -> None:
    configured = bool(settings.da_access_token or settings.da_client_id)
    if not configured:
        # не трогаем БД каждые 10 секунд: бесплатные базы тратят часы работы на каждое пробуждение
        log.warning("DonationAlerts не настроен — автоматическая проверка платежей выключена")
    backoff = settings.da_poll_interval
    last_expire = 0.0
    async with httpx.AsyncClient(timeout=20) as c:
        while not stop.is_set():
            try:
                if configured:
                    await poll_once(settings, c, expire=False)
                if time.monotonic() - last_expire > 300:
                    async with session_scope() as s:
                        await payment_service.expire_stale(s)
                    last_expire = time.monotonic()
                backoff = settings.da_poll_interval
            except Exception as e:  # сеть/API — не роняем приложение
                log.exception("DA poll failed: %s", e)
                backoff = min(backoff * 2, 300)
            try:
                await asyncio.wait_for(stop.wait(), timeout=max(2, backoff))
            except asyncio.TimeoutError:
                pass


__all__ = ["authorize_url", "sign_state", "verify_state", "exchange_code", "run_poller", "poll_once", "token_status"]
