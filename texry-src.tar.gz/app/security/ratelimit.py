"""Простой in-memory лимитер (скользящее окно). Для нескольких инстансов замените на Redis."""
from __future__ import annotations

import time
from collections import defaultdict, deque


class RateLimiter:
    def __init__(self) -> None:
        self._hits: defaultdict[str, deque[float]] = defaultdict(deque)

    def hit(self, key: str, limit: int, window: float, now: float | None = None) -> bool:
        """True — запрос разрешён, False — превышен лимит."""
        t = now if now is not None else time.monotonic()
        q = self._hits[key]
        while q and t - q[0] > window:
            q.popleft()
        if len(q) >= limit:
            return False
        q.append(t)
        if len(self._hits) > 50_000:  # защита от раздувания памяти
            self._gc(t)
        return True

    def _gc(self, t: float) -> None:
        for k in [k for k, q in self._hits.items() if not q or t - q[-1] > 3600]:
            del self._hits[k]


limiter = RateLimiter()
