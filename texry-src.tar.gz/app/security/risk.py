"""Антиабуз: нормализация телефонов, оценка риска аккаунта."""
from __future__ import annotations

import hashlib
import hmac
import re
import secrets

from app.config import Settings

# Весы сигналов риска
W_FRESH_ID = 2
W_NO_USERNAME = 1
W_NO_PHOTO = 1
W_PHONE_REUSE = 3
W_FAST_TAPS = 2


class PhoneRejected(Exception):
    def __init__(self, reason: str):
        super().__init__(reason)
        self.reason = reason


def normalize_phone(raw: str) -> str:
    digits = re.sub(r"\D", "", raw or "")
    if len(digits) == 11 and digits.startswith("8"):  # 8XXXXXXXXXX → 7XXXXXXXXXX
        digits = "7" + digits[1:]
    if not 8 <= len(digits) <= 15:
        raise PhoneRejected("bad_format")
    return digits


def check_phone_allowed(digits: str, settings: Settings) -> None:
    for prefix in settings.blocked_phone_prefixes:
        if prefix and digits.startswith(prefix):
            raise PhoneRejected("virtual_number")


def phone_hash(digits: str, secret: str) -> str:
    return hmac.new(secret.encode(), f"phone:{digits}".encode(), hashlib.sha256).hexdigest()


def initial_risk(user_id: int, username: str | None, has_photo: bool | None, is_premium: bool, settings: Settings) -> tuple[int, list[str]]:
    score, flags = 0, []
    if settings.new_account_id_threshold and user_id >= settings.new_account_id_threshold:
        score += W_FRESH_ID
        flags.append("fresh_id")
    if not username:
        score += W_NO_USERNAME
        flags.append("no_username")
    if has_photo is False:
        score += W_NO_PHOTO
        flags.append("no_photo")
    if is_premium:
        score = max(0, score - 2)  # Premium — платящий реальный аккаунт
        flags.append("premium")
    return score, flags


_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"  # без 0/O и 1/I


def random_code(n: int) -> str:
    return "".join(secrets.choice(_ALPHABET) for _ in range(n))
