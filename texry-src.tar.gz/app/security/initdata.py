"""Проверка подписи данных Telegram Mini App.

Алгоритм: https://core.telegram.org/bots/webapps#validating-data-received-via-the-mini-app
secret_key = HMAC_SHA256(key="WebAppData", msg=bot_token)
hash       = hex(HMAC_SHA256(key=secret_key, msg=data_check_string))
data_check_string — все поля, кроме hash, отсортированные по ключу, в виде key=value через \\n.

Тот же алгоритм подписывает ответ WebApp.requestContact, поэтому функция общая.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import time
from urllib.parse import parse_qsl


class InvalidInitData(Exception):
    pass


def _secret(bot_token: str) -> bytes:
    return hmac.new(b"WebAppData", bot_token.encode(), hashlib.sha256).digest()


def sign_query(fields: dict[str, str], bot_token: str) -> str:
    """Подписывает поля так же, как Telegram (используется в тестах и dev-режиме)."""
    dcs = "\n".join(f"{k}={v}" for k, v in sorted(fields.items()))
    h = hmac.new(_secret(bot_token), dcs.encode(), hashlib.sha256).hexdigest()
    from urllib.parse import urlencode

    return urlencode({**fields, "hash": h})


def verify_signed_query(raw: str, bot_token: str, max_age: int | None = 86400, now: float | None = None) -> dict[str, str]:
    if not raw or len(raw) > 8192:
        raise InvalidInitData("empty or too long")
    try:
        pairs = parse_qsl(raw, keep_blank_values=True, strict_parsing=True)
    except ValueError as e:
        raise InvalidInitData("malformed") from e
    data = dict(pairs)
    if len(data) != len(pairs):
        raise InvalidInitData("duplicate keys")
    received = data.pop("hash", None)
    if not received:
        raise InvalidInitData("no hash")
    dcs = "\n".join(f"{k}={v}" for k, v in sorted(data.items()))
    expected = hmac.new(_secret(bot_token), dcs.encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected, received):
        raise InvalidInitData("bad hash")
    if max_age is not None:
        try:
            auth_date = int(data.get("auth_date", "0"))
        except ValueError as e:
            raise InvalidInitData("bad auth_date") from e
        current = now if now is not None else time.time()
        if auth_date <= 0 or current - auth_date > max_age or auth_date - current > 300:
            raise InvalidInitData("expired")
    return data


def parse_init_data(raw: str, bot_token: str, max_age: int = 86400, now: float | None = None) -> dict:
    """Возвращает {'user': {...}, 'start_param': str|None, 'auth_date': int, 'query_id': ...}."""
    data = verify_signed_query(raw, bot_token, max_age=max_age, now=now)
    try:
        user = json.loads(data["user"])
    except (KeyError, ValueError) as e:
        raise InvalidInitData("no user") from e
    if not isinstance(user, dict) or not isinstance(user.get("id"), int) or user.get("is_bot"):
        raise InvalidInitData("bad user")
    return {
        "user": user,
        "start_param": data.get("start_param"),
        "auth_date": int(data["auth_date"]),
        "chat_type": data.get("chat_type"),
    }


def parse_contact_response(raw: str, bot_token: str, now: float | None = None) -> dict:
    """Ответ WebApp.requestContact: contact=<json>&auth_date=...&hash=..."""
    data = verify_signed_query(raw, bot_token, max_age=600, now=now)
    try:
        contact = json.loads(data["contact"])
    except (KeyError, ValueError) as e:
        raise InvalidInitData("no contact") from e
    if not isinstance(contact, dict) or "phone_number" not in contact:
        raise InvalidInitData("bad contact")
    return contact
